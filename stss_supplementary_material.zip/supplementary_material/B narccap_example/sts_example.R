# sts_example

load("usa_tasmax.rda")
library(hero)

sts = as.sts(usa_tasmax)
set.seed(1)
e1 = enlarge(usa_sppoly)
plot(e1)

colors = rev(c("#66c2a5", "#fc8d62", "#8da0cb"))
s1 = radspline(nknots = 50, poverlap = 3, longlat = TRUE, border = usa_sppoly)
plot(s1)
s2 = radspline(nknots = 200, poverlap = 3, border = usa_sppoly,
               width = s1$width/2, longlat = TRUE)
plot(s2)
s3 = radspline(nknots = 800, poverlap = 3, border = usa_sppoly,
               width = s2$width/2, longlat = TRUE)
rs = connect(s1, s2, s3)

png("usa_radknots.png", height = 3, width = 6, units = "in",
    res = 300)
par(mar = c(0, 0, 0, 0))
plot(rs,
     blist = list(col = "white", lwd = 2),
     glist = list(col = colors, pch = c(15, 17, 20)),
     border = "white")
legend("bottomleft", legend = c("resolution 1", "resolution 2",
                                "resolution 3"),
       pch = c(15, 17, 20), col = colors)
dev.off()

sp_coords = sp::SpatialPoints(coords = usa_coords,
                              proj4string = sp::CRS("+proj=longlat +datum=WGS84"))
pdf("usa_coords.pdf", height = 4, width = 6)
par(mar = c(0.1, 0.1, 0.1, 0.1))
sp::plot(sp_coords, pch = ".", cex = 3)
dev.off()

sp_knots1 = sp::SpatialPoints(coords = s1$grid,
                              proj4string = sp::CRS("+proj=longlat +datum=WGS84"))
sp_knots2 = sp::SpatialPoints(coords = s2$grid,
                              proj4string = sp::CRS("+proj=longlat +datum=WGS84"))
sp_knots3 = sp::SpatialPoints(coords = s3$grid,
                              proj4string = sp::CRS("+proj=longlat +datum=WGS84"))

pdf("usa_coords_with_knots.pdf", height = 4, width = 6)
par(mar = c(0.1, 0.1, 0.1, 0.1))
sp::plot(sp_coords, pch = ".", cex = 3)
sp::plot(sp_knots1, pch = 15, col = colors[1], add = TRUE)
sp::plot(sp_knots2, pch = 17, col = colors[2], add = TRUE)
sp::plot(sp_knots3, pch = 20, col = colors[3], add = TRUE)
dev.off()

sum(rs$nbasis)

bs = bspline(c(1, 365), nbasis = 35)
plot(bs)

t3 = Sys.time()
p = prepare(sts, coords = usa_coords, times = 1:365,
            rs, bs, spdiffpen = TRUE)
p = enhance(p, method = "nlminb")
h = hero(p)
(t3 = Sys.time() - t3)

png("sts_y_vs_yhat.png", res = 300, height = 6, width = 6, units = "in")
plot(c(usa_tasmax) ~ c(h$fitted),
     xlab = "fitted values", ylab = "observed values",
     col = "lightgrey", pch = ".")
abline(0, 1)
dev.off()

