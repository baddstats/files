We have attempted to make our analyses reproducible.
To facilitate this, we have provided compressed
versions of some of the data (e.g., usa_tasmax.rda
for Section 5.1 and and tasmax_smooth.rda for
Section 4). When this was not possible
(i.e., for the NA-CORDEX data) we have provided
download links for the needed files that were
current as of early October 2019.

The files in A should be run in order, then the
files in B, then the files in C, and then the files
in D. We strongly recommend users use a multi-threaded
BLAS (e.g., the INTEL MKL or OpenBLAS) as this will
greatly speed-up the computations.

The scripts all assume the relevant data files are
available in the user's current working directory.

The following R packages should be installed to 
complete the analyses:
hero (from source)
ncdf4
abind
ggplot2
autoimage
xtable
sp

