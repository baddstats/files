library(ncdf4)
library(hero)

load("enhanced_obj_cordex.rda")
load("wna.rda")
load("coeffs_cordex.rda")
B = obj$B
# save(B, file = "B_cordex.rda", compress = "bzip2")
# load("B_cordex.rda")

set.seed(29)
sample_years = sample(1:150, 4)
sample_days = sample(1:365, 4)
sample_smooths = vector("list", 4)
sample_i = 1

t1 = Sys.time()
nco = nc_open("tasmax.hist.CanESM2.CanRCM4.day.NAM-22i.raw.nc")
pdf("cordex_y_vs_yhat.pdf")
plot(201:202 - 273.15, 201:202 - 273.15, xlab = "fitted values", ylab = "observed values",
     type = "n", xlim = (c(218, 315) - 273.15),
     ylim = (c(218, 315) - 273.15))
Min = Inf
Max = -Inf
for (i in 1:56) {
  data = ncvar_get(nco, varid = "tasmax",
                   start = c(1, 1, 365 * (i - 1) + 1),
                   count = c(600, 258, 365), 365 * (i - 1) + 1,
                   verbose = FALSE)
  stdata = matrix(c(data), ncol = dim(data)[3])
  stdata = stdata[-wna, ]
  yhat = rh.seq(B, h[[i]]$coeff)
  sub = sample(seq_len(nrow(stdata)), 1000)
  myy = c(stdata)[sub]
  myyhat = c(yhat)[sub]
  Min = pmin(Min, min(myyhat), min(myy))
  Max = pmax(Max, max(myyhat), max(myy))
  points(myyhat - 273.15, myy - 273.15, pch = ".", col = "lightgrey")
  if (is.element(i, sample_years)) {
    sample_smooths[[sample_i]] = yhat[, sample_years[sample_i]]
    sample_i = sample_i + 1
  }
  message(paste("year", i))
}
nc_close(nco)

nco = nc_open("tasmax.rcp85.CanESM2.CanRCM4.day.NAM-22i.raw.nc")
for (i in 57:150) {
  data = ncvar_get(nco, varid = "tasmax",
                   start = c(1, 1, 365 * (i - 57) + 1),
                   count = c(600, 258, 365), 365 * (i - 57) + 1,
                   verbose = FALSE)
  stdata = matrix(c(data), ncol = dim(data)[3])
  stdata = stdata[-wna, ]
  yhat = rh.seq(B, h[[i]]$coeff)
  sub = sample(seq_len(nrow(stdata)), 1000)
  myy = c(stdata)[sub]
  myyhat = c(yhat)[sub]
  Min = pmin(Min, min(myyhat), min(myy))
  Max = pmax(Max, max(myyhat), max(myy))
  points(myyhat - 273.15, myy - 273.15, pch = ".", col = "lightgrey")

  if (is.element(i, sample_years)) {
    sample_smooths[[sample_i]] = yhat[, sample_years[sample_i]]
    sample_i = sample_i + 1
  }
  message(paste("year", i))
}
nc_close(nco)
abline(0, 1)
dev.off()
(t1 = Sys.time() - t1)
Min
Max
# Time difference of 9.376238 mins
# > Min
# [1] 213.9828
# > Max
# [1] 312.4605
save(sample_smooths, file = "sample_smooths_cordex.rda", compress = "gzip")
