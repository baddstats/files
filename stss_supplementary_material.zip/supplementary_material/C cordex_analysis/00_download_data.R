# script for downloading NA-CORDEX data (works as of October 9th, 2019)
# based on future changes in the file hosting locations
# interested parties should download the following
# files from the NA-CORDEX section of earthsystemgrid.org:
# 1. 'tasmax.hist.CanESM2.CanRCM4.day.NAM-22i.raw.nc'
# 2. 'tasmax.rcp85.CanESM2.CanRCM4.day.NAM-22i.raw.nc'
# Note: download.file is very slow.  It's probably better
# to simply copy and paste the urls into your web browser
# and download the files directly or to use the wget or
# curl scripts to download the files.

# historical data
url1 = 'https://tds.ucar.edu/thredds/fileServer/datazone/cordex/data/raw/NAM-22i/day/CanRCM4/CanESM2/hist/tasmax/tasmax.hist.CanESM2.CanRCM4.day.NAM-22i.raw.nc'
download.file(url = url1,
              dest = 'tasmax.hist.CanESM2.CanRCM4.day.NAM-22i.raw.nc',
              method = "auto")
# future data
url2 = 'https://tds.ucar.edu/thredds/fileServer/datazone/cordex/data/raw/NAM-22i/day/CanRCM4/CanESM2/rcp85/tasmax/tasmax.rcp85.CanESM2.CanRCM4.day.NAM-22i.raw.nc'
download.file(url = url2,
              dest = 'tasmax.rcp85.CanESM2.CanRCM4.day.NAM-22i.raw.nc',
              method = "auto")


