library(ncdf4)
library(abind)

wnas = vector("list", 150)
nco = nc_open("tasmax.hist.CanESM2.CanRCM4.day.NAM-22i.raw.nc")
for (i in 1:56) {
  tasmax = ncvar_get(nco, varid = "tasmax",
                     start = c(1, 1, 365 * (i - 1) + 1),
                     count = c(600, 258, 365), 365 * (i - 1) + 1,
                     verbose = FALSE)
  tasmax2d = matrix(c(tasmax), ncol = 365)
  wna = which(is.na(apply(tasmax2d, 1, max)))
  wnas[[i]] = wna
  message(paste("year", i))
}
nc_close(nco)

nco = nc_open("tasmax.rcp85.CanESM2.CanRCM4.day.NAM-22i.raw.nc")
for (i in 57:150) {
  tasmax = ncvar_get(nco, varid = "tasmax",
                     start = c(1, 1, 365 * (i - 57) + 1),
                     count = c(600, 258, 365), 365 * (i - 57) + 1,
                     verbose = FALSE)
  tasmax2d = matrix(c(tasmax), ncol = 365)
  wna = which(is.na(apply(tasmax2d, 1, max)))
  wnas[[i]] = wna
  message(paste("year", i))
}
nc_close(nco)

wna = unique(unlist(wnas, use.names = FALSE))
save(wna, file = "wna.rda", compress = "bzip2")
