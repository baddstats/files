library(ncdf4)
library(abind)

# determine the polygon of the data
# load coordinates and related information
nco = nc_open("tasmax.hist.CanESM2.CanRCM4.day.NAM-22i.raw.nc")
lon = ncvar_get(nco, varid = "lon")
lat = ncvar_get(nco, varid = "lat")
save(lon, lat, file = "CanESM2.CanRCM4.lonlat.rda", compress = "bzip2")
nc_close(nco)
load("CanESM2.CanRCM4.lonlat.rda")
load("wna.rda")
coords = expand.grid(lon, lat)
nav = rnorm(nrow(coords))
nav[wna] = NA
namat = matrix(nav, ncol = length(lat), nrow = length(lon))
# verify that non-NA locations are accurate
# image(namat)

# determine least extreme NA values (west, north, east, south)
colmins = apply(!is.na(namat), 1, function(x) {
  wx = which(x)
  if (length(wx) == 0) {
    return(NA)
  } else {
    return(min(wx))
  }})
colmaxs = apply(!is.na(namat), 1, function(x) {
  wx = which(x)
  if (length(wx) == 0) {
    return(NA)
  } else {
  return(max(wx))
  }})

poly = NULL

for (i in seq_len(nrow(coords))) {
  if (!is.na(colmins[i])) {
    poly = rbind(poly, cbind(lon[i], lat[colmins[i]]))
  }
}
for (i in rev(seq_len(nrow(coords)))) {
  if (!is.na(colmins[i])) {
    poly = rbind(poly, cbind(lon[i], lat[colmaxs[i]]))
  }
}

# plot polygon for verificatoin
# plot(poly)
# return polygon as correct data structure, save for later
poly = list(x = poly[,1], y = poly[,2])
cordex_poly = hero::poly2SpatialPolygons(poly, "cordex_border")
save(cordex_poly, file = "cordex_poly.rda", compress = "bzip2")
# save non-na coordinates
cordex_coords = coords[-wna, ]
save(cordex_coords, file = "cordex_coords.rda", compress = "bzip2")
