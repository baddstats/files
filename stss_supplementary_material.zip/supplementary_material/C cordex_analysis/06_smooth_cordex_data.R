library(hero)

load("enhanced_obj_cordex.rda")

t1 = Sys.time()
h = hero(obj, fitted = FALSE)
for (i in seq_along(h)) {
  yhat = rh.seq(obj$B, h[[i]]$coeff)
  message(paste("year", i))
}
(t1 = Sys.time() - t1)
# Time difference of 5.140052 mins
save(h, file = "coeffs_cordex.rda", compress = "gzip")

