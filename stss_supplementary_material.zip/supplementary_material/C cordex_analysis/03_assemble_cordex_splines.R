library(hero)

load("cordex_coords.rda")
load("cordex_poly.rda")

t1 = Sys.time()
set.seed(1)
# setup radial splines
s1 = radspline(nknots = 200, poverlap = 4, border = cordex_poly,
               longlat = TRUE, k = 1)
s2 = radspline(nknots = 400, poverlap = 4, border = cordex_poly,
               width = s1$width/2, longlat = TRUE, k = 1)
s3 = radspline(nknots = 800, poverlap = 4, border = cordex_poly,
               width = s1$width/2.5, longlat = TRUE, k = 1)
s4 = radspline(nknots = 1200, poverlap = 4, border = cordex_poly,
               longlat = TRUE, k = 1, width = s1$width/3)

# combine into one layer
rs = connect(s1, s2, s3, s4)

# plot(rs)

# set of temporal b-splines
bs = bspline(c(1, 365), nbasis = 35)
# plot(bs)

# combine splines into list
splines = list(rs, bs)

# setup of locations to evaluate basis functions
x = list(as.matrix(cordex_coords), seq_len(365))

# assemble spline information
a = assemble(splines, x = x, m = c(1, 2))

# determine execution time
t1 = Sys.time() - t1
print(t1)

# Time difference of 3.648253 mins
save(x, file = "cordex_evalargs.rda", compress = "gzip")
save(a, file = "cordex_assembled_splines.rda", compress = "gzip")
save(splines, file = "cordex_splines.rda", compress = "gzip")

