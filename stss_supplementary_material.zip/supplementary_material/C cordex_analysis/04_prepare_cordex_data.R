library(ncdf4)
library(hero)

load("cordex_evalargs.rda")
load("cordex_assembled_splines.rda")
load("cordex_splines.rda")
load("wna.rda")

Ytilde = vector("list", 150)
sum_ysq = numeric(150)

t1 = Sys.time()
nco = nc_open("tasmax.hist.CanESM2.CanRCM4.day.NAM-22i.raw.nc")
for (i in 1:56) {
  data = ncvar_get(nco, varid = "tasmax",
                     start = c(1, 1, 365 * (i - 1) + 1),
                     count = c(600, 258, 365), 365 * (i - 1) + 1,
                     verbose = FALSE)
  stdata = matrix(c(data), ncol = dim(data)[3])
  stdata = stdata[-wna, ]

  Ytilde[[i]] = prepare(stdata, x = x, splines = splines, assembled = a)$Ytilde
  sum_ysq[i] = sum(stdata^2)

  message(paste("year", i))
}
nc_close(nco)

nco = nc_open("tasmax.rcp85.CanESM2.CanRCM4.day.NAM-22i.raw.nc")
for (i in 57:150) {
  data = ncvar_get(nco, varid = "tasmax",
                     start = c(1, 1, 365 * (i - 57) + 1),
                     count = c(600, 258, 365), 365 * (i - 57) + 1,
                     verbose = FALSE)
  stdata = matrix(c(data), ncol = dim(data)[3])
  stdata = stdata[-wna, ]

  Ytilde[[i]] = prepare(stdata, x = x, splines = splines, assembled = a)$Ytilde
  sum_ysq[i] = sum(stdata^2)
  n = dim(stdata)

  message(paste("year", i))
}
nc_close(nco)
(t1 = Sys.time() - t1)
# Time difference of 10.27988 mins

save(Ytilde, file = "Ytilde.rda", compress = "gzip")
save(sum_ysq, file = "sum_ysq.rda", compress = "gzip")
n = c(93190, 365)
save(n, file = "n.rda", compress = "gzip")

