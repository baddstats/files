library(hero)

load("cordex_evalargs.rda")
load("cordex_assembled_splines.rda")
load("cordex_splines.rda")
load("Ytilde.rda")
load("sum_ysq.rda")
load("n.rda")
load("wna.rda")

t1 = Sys.time()
obj = create.prepared_list(assembled = a, x = x, n = n,
                           Ytilde = Ytilde, sum_ysq = sum_ysq)
g = expand.grid(seq(-20, 20, len = 11), seq(-20, 20, len = 11))
eout = enhance.grid(obj, par = g, prepare = FALSE)
wmin = which.min(eout$gcv)
eout[wmin, ]
eout2 = enhance(obj, par = c(-20, -8),
              lower = c(-30, -11),
              upper = c(-17, -5),
              method = "nlminb",
              loggcv = TRUE,
              prepare = FALSE)
eout2
g = cbind(-30, seq(-10, -6, len = 21))
eout3 = enhance.grid(obj, par = g, prepare = FALSE, loggcv = FALSE)
wmin2 = which.min(eout3$gcv)
eout3[wmin2,]
obj = enhance(obj, par = c(-30, -8.4),
                lower = c(-30, -8.6),
                upper = c(-30, -8.2),
                method = "nlminb",
                loggcv = FALSE,
                prepare = TRUE)
rm(a)
rm(Ytilde)
rm(sum_ysq)
rm(wna)
rm(splines)
rm(x)
(t1 = Sys.time() - t1)
# Time difference of 55.41673 secs
# > obj$results
#         p1        p2       value fevals gevals niter convcode kkt1 kkt2 xtime
# nlminb -30 -8.367529 49582589022      6      6     3        0 TRUE TRUE  3.71
save(obj, file = "enhanced_obj_cordex.rda", compress = "gzip")

