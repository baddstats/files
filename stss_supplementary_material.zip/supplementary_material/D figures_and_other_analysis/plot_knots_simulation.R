load("tasmax_smooth.rda")
# devtools::load_all("~/Dropbox/Code/GitHub/hero")
library(hero)

set.seed(1)
border = border.grid(lon, lat)
s1 = radspline(nknots = 200, poverlap = 4, border = border,
               longlat = TRUE, k = 1)
s2 = radspline(nknots = 400, poverlap = 4, border = border,
               width = s1$width/2, longlat = TRUE, k = 1)
s3 = radspline(nknots = 800, poverlap = 4, border = border,
               width = s1$width/2.5, longlat = TRUE, k = 1)
s4 = radspline(nknots = 1200, poverlap = 4, border = border,
               longlat = TRUE, k = 1, width = s1$width/3)
s5 = radspline(nknots = 1600, poverlap = 4, border = border,
               width = s1$width/3, longlat = TRUE, k = 1)
# old version of figure
# rsa = connect(s1, s2, s3)
#
# colors = rev(c("#66c2a5", "#fc8d62", "#8da0cb"))
# png("radknots.png", height = 3, width = 6, units = "in",
#     res = 300)
# par(mar = c(0, 0, 0, 0))
# plot(rsa,
#      blist = list(col = "white", lwd = 2),
#      glist = list(col = colors, pch = c(15:17)),
#      border = "white")
# legend("bottomleft", legend = c("resolution 1", "resolution 2",
#                                 "resolution 3"),
#        pch = c(15:17), col = colors)
# dev.off()

# simplified version of figure
rsa = connect(s1, s2)
colors = rev(c("#8da0cb", "#fc8d62"))
png("radknots.png", height = 3, width = 6, units = "in",
    res = 300)
par(mar = c(0, 0, 0, 0))
plot(rsa,
     blist = list(col = "white", lwd = 2),
     glist = list(col = colors, pch = 15:16),
     border = "white")
legend("bottomleft", legend = c("resolution 1", "resolution 2"),
       pch = 15:16, col = colors)
dev.off()