library(xtable)
dia = diag(5)
diff(dia, differences = 1)
diff(dia, differences = 2)
diff(dia, differences = 3)
diff(dia, differences = 4)

g = expand.grid(1:3, 1:4)
adj = adjacent(g, digits = 1)

pdf("neighbors.pdf")
par(mar = rep(0.1, 4))
plot(adj)
dev.off()

s1 = spdiffpen(g, m = 1, sparse = FALSE, digits = 1)
s2 = spdiffpen(g, m = 2, sparse = FALSE, digits = 1)
