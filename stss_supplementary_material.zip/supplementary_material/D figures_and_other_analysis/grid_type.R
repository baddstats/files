data(tasmax, package = "hero")

x1 = seq(min(lon), max(lon), len = 147)
x2 = seq(min(lat), max(lat), len = 116)
s1 = seq(1, 147, by = 10)
s2 = seq(1, 116, by = 10)
s = expand.grid(s1, s2)

u = c(1, 10, 15, 25, 33, 47, 60, 85, 97, 107, 117, 127, 137, 147)
v = c(1, 20, 25, 30, 35, 40, 56, 66, 76, 86, 106, 116) # seq(1, 116, by = 10)

# xx = expand.grid(x1[s1], x2[s2])
xx = expand.grid(u, v)
lon2 = lon[s1, ]
lon2 = lon2[,s2]
lat2 = lat[s1, ]
lat2 = lat2[,s2]

pdf("grids.pdf", height = 6, width = 12)
par(mfrow = c(1, 2))
plot(xx[,1], xx[,2],
     xlab = "u", ylab = "v", pch = 20)
title("(a) rectilinear grid", cex.main = 2)
plot(lon[s[,1], s[,2]], lat[s[,1], s[,2]],
     pch = 20, xlab = "u", ylab = "v")
title("(b) irregular grid", cex.main = 2)
dev.off()
