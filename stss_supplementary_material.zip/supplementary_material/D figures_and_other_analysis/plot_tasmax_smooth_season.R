load("tasmax_smooth.rda")
# march 20 [80]
# june 21 [172]
# september 22 [265]
# december 11 [355]
library(autoimage)
png("tasmax_smooth_season.png",
    width = 6, height = 6, units = "in", res = 300)
autoimage(lon, lat, tasmax_smooth[,,c(80, 172, 265, 355)],
          main = c("March 20", "June 21",
                   "September 22", "December 21"),
          proj = "bonne", parameters = 40,
          map = "world",
          xlab = "longitude", ylab = "latitude",
          # lines.args = list(col = "grey"),
          paxes.args = list(col = "grey"))
dev.off()
