# combine and organize all information
load("simulation_out_norm.rda")
norm_mses = all_mses
norm_times = sapply(all, getElement, name = "time")
normcis = apply(norm_mses, 1, function(x) t.test(x)$conf.int[1:2])
load("simulation_out_svcnorm.rda")
svcnorm_mses = all_mses
svcnorm_times = sapply(all, getElement, name = "time")
svcnormcis = apply(svcnorm_mses, 1, function(x) t.test(x)$conf.int[1:2])
load("simulation_out_t8.rda")
t8_mses = all_mses
t8_times = sapply(all, getElement, name = "time")
t8cis = apply(t8_mses, 1, function(x) t.test(x)$conf.int[1:2])
load("simulation_out_t4.rda")
t4_mses = all_mses
t4_times = sapply(all, getElement, name = "time")
t4cis = apply(t4_mses, 1, function(x) t.test(x)$conf.int[1:2])

# format results from each simulation
normdf = data.frame(mse = c(t(norm_mses)),
                    scenario = "A",
                    smooth = rep(letters[1:10], each = 100))
svcnorm_df = data.frame(mse = c(t(svcnorm_mses)),
                        scenario = "B",
                        smooth = rep(letters[1:10], each = 100))
t8df = data.frame(mse = c(t(t8_mses)),
                  scenario = "C",
                  smooth = rep(letters[1:10], each = 100))
t4df = data.frame(mse = c(t(t4_mses)),
                  scenario = "D",
                  smooth = rep(letters[1:10], each = 100))
df = rbind(normdf,
           svcnorm_df,
           t8df,
           t4df)

# summarize results
library(dplyr)
out = df %>% group_by(scenario, smooth) %>%
  summarize(avg_mse = mean(mse),
            # med_mse = median(mse),
            # sd_mse = sd(mse)
            )

out$lb = c(normcis[1, ], svcnormcis[1,], t8cis[1,], t4cis[1,])
out$ub = c(normcis[2, ], svcnormcis[2,], t8cis[2,], t4cis[2,])

outdf = as.data.frame(out)
out_reformat = rbind(cbind(outdf[1:10, ], outdf[11:20, ]),
                     cbind(outdf[21:30, ], outdf[31:40, ]))


print(xtable::xtable(out_reformat, digits = 6), include.rownames = FALSE)

# average simulation time for normal data
rowMeans(norm_times)

# boxplot of results for each scenario
library(ggplot2)
png("mse_boxplots.png", height = 6, width = 6,
    units = "in", res = 300)
print(ggplot(df) + geom_boxplot(aes(x = smooth, y = mse)) +
  facet_wrap(~ scenario, scales = "free_y") +
  theme_bw())
dev.off()