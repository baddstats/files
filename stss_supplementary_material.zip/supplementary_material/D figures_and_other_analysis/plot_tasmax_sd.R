load("tasmax_smooth.rda")
load("tasmax_sd.rda")
png("tasmax_sd.png",
    width = 6, height = 6, units = "in", res = 300)
autoimage::autoimage(lon, lat, tasmax_sd,
                     map = "world",
                     proj = "bonne", parameters = 40,
                     xlab = "longitude", ylab = "latitude",
                     paxes.args = list(col = "grey"))
dev.off()
