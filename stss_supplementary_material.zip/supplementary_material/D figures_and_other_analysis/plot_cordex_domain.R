load("cordex_coords.rda")
load("cordex_poly.rda")
load("wna.rda")
load("cordex_lonlat.rda")

# library(ncdf4)
# nco = nc_open("tasmax.hist.CanESM2.CanRCM4.day.NAM-22i.raw.nc")
# lon = ncvar_get(nco, varid = "lon")
# lat = ncvar_get(nco, varid = "lat")
# nc_close(nco)
# save(lon, lat, file = "cordex_lonlat.rda", compress = "gzip")

domain = rep(1, length(lon) * length(lat))
domain[wna] = 0
dmat = matrix(domain, nrow = length(lon))

png("cordex_domain.png",
    width = 6, height = 6, units = "in", res = 300)
autoimage::autoimage(lon, lat, dmat, legend = "none",
                     map = "world",
                     proj = "bonne", parameters = 40,
                     xlab = "longitude", ylab = "latitude",
                     paxes.args = list(col = "grey"),
                     col = c("white", "darkgrey"),
                     xlim = c(-130, -65),
                     ylim = range(cordex_coords[,2]),
                     axis.args = list(yat = seq(0, 80, by = 10),
                                      xat = seq(-220, 20, by = 15)))
dev.off()