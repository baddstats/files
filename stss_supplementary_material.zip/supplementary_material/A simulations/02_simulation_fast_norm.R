load("tasmax_smooth.rda")
load("sim_assembled.rda")
# devtools::load_all("~/Dropbox/Code/GitHub/hero")
library(hero)
nsim = 100
d = dim(tasmax_smooth)
tasmax_smooth_2d = matrix(c(tasmax_smooth), ncol = d[3])
set.seed(1)

# i = simulation number
# df = degrees of freedom (only relevant for t)
test = function(i, df) {
  # simulate and format new data
  data = tasmax_smooth + array(rnorm(prod(d), sd = 3), dim = d)
  # stdata = starray(data)
  stdata = matrix(c(data), ncol = dim(data)[3])

  tp_p1 = Sys.time()
    rh_p1 = prepare(data, x = evalargs, splines = splines,
                  assembled = a_p1)
    rh_p1 = enhance(rh_p1, method = "nlminb")
    yhat_p1 = hero(rh_p1)
  tp_p1 = Sys.time() - tp_p1

  tp_p2 = Sys.time()
    rh_p2 = prepare(data, x = evalargs, splines = splines,
                    assembled = a_p2)
    rh_p2 = enhance(rh_p2, method = "nlminb")
    yhat_p2 = hero(rh_p2)
  tp_p2 = Sys.time() - tp_p2

  tp_rsa_m1 = Sys.time()
    rh_rsa_m1 = prepare(stdata, x = x2,
                  splines = list(rsa, bst),
                  assembled = a_rsa_m1)
    rh_rsa_m1 = enhance(rh_rsa_m1, method = "nlminb")
    yhat_rsa_m1 = hero(rh_rsa_m1)
  tp_rsa_m1 = Sys.time() - tp_rsa_m1

  tp_rsa_m2 = Sys.time()
    rh_rsa_m2 = prepare(stdata, x = x2,
                        splines = list(rsa, bst),
                        assembled = a_rsa_m2)
    rh_rsa_m2 = enhance(rh_rsa_m2, method = "nlminb")
    yhat_rsa_m2 = hero(rh_rsa_m2)
  tp_rsa_m2 = Sys.time() - tp_rsa_m2

  tp_rsb_m1 = Sys.time()
  rh_rsb_m1 = prepare(stdata, x = x2,
                      splines = list(rsb, bst),
                      assembled = a_rsb_m1)
  rh_rsb_m1 = enhance(rh_rsb_m1, method = "nlminb")
  yhat_rsb_m1 = hero(rh_rsb_m1)
  tp_rsb_m1 = Sys.time() - tp_rsb_m1

  tp_rsb_m2 = Sys.time()
  rh_rsb_m2 = prepare(stdata, x = x2,
                      splines = list(rsb, bst),
                      assembled = a_rsb_m2)
  rh_rsb_m2 = enhance(rh_rsb_m2, method = "nlminb")
  yhat_rsb_m2 = hero(rh_rsb_m2)
  tp_rsb_m2 = Sys.time() - tp_rsb_m2

  tp_rsc_m1 = Sys.time()
  rh_rsc_m1 = prepare(stdata, x = x2,
                      splines = list(rsc, bst),
                      assembled = a_rsc_m1)
  rh_rsc_m1 = enhance(rh_rsc_m1, method = "nlminb")
  yhat_rsc_m1 = hero(rh_rsc_m1)
  tp_rsc_m1 = Sys.time() - tp_rsc_m1

  tp_rsc_m2 = Sys.time()
  rh_rsc_m2 = prepare(stdata, x = x2,
                      splines = list(rsc, bst),
                      assembled = a_rsc_m2)
  rh_rsc_m2 = enhance(rh_rsc_m2, method = "nlminb")
  yhat_rsc_m2 = hero(rh_rsc_m2)
  tp_rsc_m2 = Sys.time() - tp_rsc_m2

  tp_rsa2_m1 = Sys.time()
  rh_rsa2_m1 = prepare(stdata, x = x2,
                      splines = list(rsa2, bst),
                      assembled = a_rsa2_m1)
  rh_rsa2_m1 = enhance(rh_rsa2_m1, method = "nlminb")
  yhat_rsa2_m1 = hero(rh_rsa2_m1)
  tp_rsa2_m1 = Sys.time() - tp_rsa2_m1

  tp_rsa2_m2 = Sys.time()
  rh_rsa2_m2 = prepare(stdata, x = x2,
                      splines = list(rsa2, bst),
                      assembled = a_rsa2_m2)
  rh_rsa2_m2 = enhance(rh_rsa2_m2, method = "nlminb")
  yhat_rsa2_m2 = hero(rh_rsa2_m2)
  tp_rsa2_m2 = Sys.time() - tp_rsa2_m2

  mse_p1 = mse(tasmax_smooth, yhat_p1)
  mse_p2 = mse(tasmax_smooth, yhat_p2)
  mse_rsa_m1 = mse(tasmax_smooth_2d, yhat_rsa_m1)
  mse_rsa_m2 = mse(tasmax_smooth_2d, yhat_rsa_m2)
  mse_rsb_m1 = mse(tasmax_smooth_2d, yhat_rsb_m1)
  mse_rsb_m2 = mse(tasmax_smooth_2d, yhat_rsb_m2)
  mse_rsc_m1 = mse(tasmax_smooth_2d, yhat_rsc_m1)
  mse_rsc_m2 = mse(tasmax_smooth_2d, yhat_rsc_m2)
  mse_rsa2_m1 = mse(tasmax_smooth_2d, yhat_rsa2_m1)
  mse_rsa2_m2 = mse(tasmax_smooth_2d, yhat_rsa2_m2)

  mse_out = c(mse_p1, mse_p2,
              mse_rsa_m1, mse_rsa_m2,
              mse_rsb_m1, mse_rsb_m2,
              mse_rsc_m1, mse_rsc_m2,
              mse_rsa2_m1, mse_rsa2_m2)
  times_out = c(ta_p1 + tp_p1, ta_p2 + tp_p2,
                ta_rsa_m1 + tp_rsa_m1, ta_rsa_m2 + tp_rsa_m2,
                ta_rsb_m1 + tp_rsb_m1, ta_rsb_m2 + tp_rsb_m2,
                ta_rsc_m1 + tp_rsc_m1, ta_rsc_m2 + tp_rsc_m2,
                ta_rsa2_m1 + tp_rsa2_m1, ta_rsa2_m2 + tp_rsa2_m2)
  list(mse = mse_out, time = times_out)
}

all = pbapply::pblapply(seq_len(nsim), test, df = 4)
all_mses = sapply(all, getElement, name = "mse")
sim_name = c("bivariate p-spline with m = 1",
             "bivariate p-spline with m = 2",
             "stss with 3 scales, 1213 radial knots, Wendland order k = 1, m = 1",
             "stss with 3 scales, 1213 radial knots, Wendland order k = 1, m = 2",
             "stss with 4 scales, 2244 radial knots, Wendland order k = 1, m = 1",
             "stss with 4 scales, 2244 radial knots, Wendland order k = 1, m = 2",
             "stss with 5 scales, 3632 radial knots, Wendland order k = 1, m = 1",
             "stss with 5 scales, 3632 radial knots, Wendland order k = 1, m = 2",
             "stss with 3 scales, 1213 radial knots, Wendland order k = 2, m = 1",
             "stss with 3 scales, 1213 radial knots, Wendland order k = 2, m = 2")
msedf = data.frame(mse = c(all_mses), smooth = rep(sim_name, each = nsim))
cis = apply(all_mses, 1, function(x) t.test(x)$conf.int[1:2])
results = data.frame(
               mean = apply(all_mses, 1, mean),
               median = apply(all_mses, 1, median),
               se = apply(all_mses, 1, sd)/sqrt(nsim),
               lb = cis[,1], ub = cis[,2])
xtable::xtable(results, digits = 6)
save(all_mses, all, file = "simulation_out_norm.rda", compress = "xz")
