load("tasmax_smooth.rda")
# devtools::load_all("~/Dropbox/Code/GitHub/hero")
library(hero)
nsim = 100

set.seed(1)
# create radial basis functions at different scales
# with k = 1
border = border.grid(lon, lat)
s1 = radspline(nknots = 200, poverlap = 4, border = border,
               longlat = TRUE, k = 1)
s2 = radspline(nknots = 400, poverlap = 4, border = border,
               width = s1$width/2, longlat = TRUE, k = 1)
s3 = radspline(nknots = 800, poverlap = 4, border = border,
               width = s1$width/2.5, longlat = TRUE, k = 1)
s4 = radspline(nknots = 1200, poverlap = 4, border = border,
               longlat = TRUE, k = 1, width = s1$width/3)
s5 = radspline(nknots = 1600, poverlap = 4, border = border,
               width = s1$width/3, longlat = TRUE, k = 1)
rsa = connect(s1, s2, s3)
rsb = connect(s1, s2, s3, s4)
rsc = connect(s1, s2, s3, s4, s5)

# create radial basis functions at different scales
# with k = 2
s1.2 = radspline(nknots = 200, poverlap = 4, border = border,
               longlat = TRUE, k = 2)
s2.2 = radspline(nknots = 400, poverlap = 4, border = border,
               width = s1$width/2, longlat = TRUE, k = 2)
s3.2 = radspline(nknots = 800, poverlap = 4, border = border,
               width = s1$width/2.5, longlat = TRUE, k = 2)
s4.2 = radspline(nknots = 1200, poverlap = 4, border = border,
               longlat = TRUE, k = 2, width = s1$width/3)
s5.2 = radspline(nknots = 1600, poverlap = 4, border = border,
               width = s1$width/3, longlat = TRUE, k = 2)
rsa2 = connect(s1.2, s2.2, s3.2)
rsb2 = connect(s1.2, s2.2, s3.2, s4.2)
rsc2 = connect(s1.2, s2.2, s3.2, s4.2, s5.2)

# observed locations for 3d data
evalargs = list(seq(min(lon), max(lon), len = nrow(tasmax_smooth)),
                seq(min(lat), max(lat), len = ncol(tasmax_smooth)),
                seq_len(365))
# location information for radial splines
x2 = list(cbind(c(lon), c(lat)), evalargs[[3]])
# observed data for radial splines
tasmax_smooth_2d = matrix(c(tasmax_smooth), ncol = d[3])


# construct bsplines
bsx = bspline(range(evalargs[[1]]), nbasis = 60)
bsy = bspline(range(evalargs[[2]]), nbasis = 60)
bst = bspline(c(1, 365), nbasis = 35)
splines = list(bsx, bsy, bst)
d = dim(tasmax_smooth)

# functions for computing mse
mse = function(y, yhat) {
  mean((y - yhat$fitted)^2)
}

# assemble information for many different combinations of splines
# bsplines with m = 1
ta_p1 = Sys.time()
a_p1 = assemble(splines, x = evalargs, m = 1)
ta_p1 = Sys.time() - ta_p1

# bsplines with m = 2
ta_p2 = Sys.time()
a_p2 = assemble(splines, x = evalargs, m = 2)
ta_p2 = Sys.time() - ta_p2

# penalize rsa with m = 1
ta_rsa_m1 = Sys.time()
a_rsa_m1 = assemble(list(rsa, bst), x = x2, spdiffpen = TRUE,
              m = c(1, 2))
ta_rsa_m1 = Sys.time()  - ta_rsa_m1

# penalize rsa with m = 2
ta_rsa_m2 = Sys.time()
a_rsa_m2 = assemble(list(rsa, bst), x = x2, spdiffpen = TRUE,
                    m = c(2, 2))
ta_rsa_m2 = Sys.time() - ta_rsa_m2

# penalize rsb with m = 1
ta_rsb_m1 = Sys.time()
a_rsb_m1 = assemble(list(rsb, bst), x = x2, spdiffpen = TRUE,
                    m = c(1, 2))
ta_rsb_m1 = Sys.time()  - ta_rsb_m1

# penalize rsb with m = 2
ta_rsb_m2 = Sys.time()
a_rsb_m2 = assemble(list(rsb, bst), x = x2, spdiffpen = TRUE,
                    m = c(2, 2))
ta_rsb_m2 = Sys.time() - ta_rsb_m2

# penalize rsc with m = 1
ta_rsc_m1 = Sys.time()
a_rsc_m1 = assemble(list(rsc, bst), x = x2, spdiffpen = TRUE,
                    m = c(1, 2))
ta_rsc_m1 = Sys.time()  - ta_rsc_m1

# penalize rsc with m = 2
ta_rsc_m2 = Sys.time()
a_rsc_m2 = assemble(list(rsc, bst), x = x2, spdiffpen = TRUE,
                    m = c(2, 2))
ta_rsc_m2 = Sys.time() - ta_rsc_m2

# penalize rsa2 with m = 1
ta_rsa2_m1 = Sys.time()
a_rsa2_m1 = assemble(list(rsa2, bst), x = x2, spdiffpen = TRUE,
                    m = c(1, 2))
ta_rsa2_m1 = Sys.time()  - ta_rsa2_m1

# penalize rsa2 with m = 2
ta_rsa2_m2 = Sys.time()
a_rsa2_m2 = assemble(list(rsa2, bst), x = x2, spdiffpen = TRUE,
                    m = c(2, 2))
ta_rsa2_m2 = Sys.time() - ta_rsa2_m2

# # penalize rsb2 with m = 1
# ta_rsb2_m1 = Sys.time()
# a_rsb2_m1 = assemble(list(rsb2, bst), x = x2, spdiffpen = TRUE,
#                     m = c(1, 2))
# ta_rsb2_m1 = Sys.time()  - ta_rsb2_m1
#
# # penalize rsb2 with m = 2
# ta_rsb2_m2 = Sys.time()
# a_rsb2_m2 = assemble(list(rsb2, bst), x = x2, spdiffpen = TRUE,
#                     m = c(2, 2))
# ta_rsb2_m2 = Sys.time() - ta_rsb2_m2

# # penalize rsc2 with m = 1
# ta_rsc2_m1 = Sys.time()
# a_rsc2_m1 = assemble(list(rsc2, bst), x = x2, spdiffpen = TRUE,
#                     m = c(1, 2))
# ta_rsc2_m1 = Sys.time()  - ta_rsc2_m1
#
# # penalize rsc.2 with m = 2
# ta_rsc2_m2 = Sys.time()
# a_rsc2_m2 = assemble(list(rsc2, bst), x = x2, spdiffpen = TRUE,
#                     m = c(2, 2))
# ta_rsc2_m2 = Sys.time() - ta_rsc2_m2

# plots radial basis functions knot locations
colors = rev(c("#66c2a5", "#fc8d62", "#8da0cb"))

png("radknots.png", height = 3, width = 6, units = "in",
    res = 300)
par(mar = c(0, 0, 0, 0))
plot(rsa,
     blist = list(col = "white", lwd = 2),
     glist = list(col = colors, pch = c(15:17)),
     border = "white")
legend("bottomleft", legend = c("resolution 1", "resolution 2",
                             "resolution 3"),
       pch = c(15:17), col = colors)
dev.off()

# save relevant info for simulations
save(evalargs, x2,
     splines, bst,
     rsa, rsb, rsc,
     rsa2, rsb2, rsc2,
     a_p1, a_p2,
     a_rsa_m1, a_rsa_m2,
     a_rsb_m1, a_rsb_m2,
     a_rsc_m1, a_rsc_m2,
     a_rsa2_m1, a_rsa2_m2,
#     a_rsb2_m1, a_rsb2_m2,
#     a_rsc2_m1, a_rsc2_m2,
     mse,
     ta_p1, ta_p2,
     ta_rsa_m1, ta_rsa_m2,
     ta_rsb_m1, ta_rsb_m2,
     ta_rsc_m1, ta_rsc_m2,
     ta_rsa2_m1, ta_rsa2_m2,
#     ta_rsb2_m1, ta_rsb2_m2,
#     ta_rsc2_m1, ta_rsc2_m2,
    file = "sim_assembled.rda",
     compress = "bzip2")